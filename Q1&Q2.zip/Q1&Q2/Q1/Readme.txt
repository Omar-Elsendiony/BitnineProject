Constructing pointers to functions was made as follows:

-Defining the functions that resemble the arithmetic operations
-Deciding upon the enums that will distinguish each function so that we return the right pointer to that function
-Comprehending the required arguments for each function for example add and mul takes integer whereas sub takes pointer to a node


-Running the code is done using basic c compiler (gcc), the program will prompt the user to enter some inputs
--- The first two inputs are the two addition operands
--- The second two inputs are the two multiplication operands

from there, these two inputs are entered by the program as inputs to the sub function and consequently the fibonacci function.